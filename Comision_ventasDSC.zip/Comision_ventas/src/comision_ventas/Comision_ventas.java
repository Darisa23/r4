/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package comision_ventas;

import java.util.Scanner;

/**
 *
 * @author DARIANA
 */
public class Comision_ventas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float sb, v1, v2, v3, tot_vta, com, trec;
        Scanner leer = new Scanner(System.in);
        System.out.print("Ingrese su sueldo base: ");
        sb = leer.nextFloat();
        System.out.print("Ingrese valor de venta 1: ");
        v1 = leer.nextFloat();
        System.out.print("Ingrese valor de venta 2: ");
        v2 = leer.nextFloat();
        System.out.print("Ingrese valor de venta 3: ");
        v3 = leer.nextFloat();
        tot_vta = (float)(v1+v2+v3);
        com = (float)(tot_vta * 0.10);
        trec = (float)(sb + com);
        System.out.println("En total recibirá: "+ trec);
        System.out.println("Su comisión fue de: "+ com);
  
    }
    
}
