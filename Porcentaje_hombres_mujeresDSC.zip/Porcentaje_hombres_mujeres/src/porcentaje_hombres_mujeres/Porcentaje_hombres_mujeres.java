/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package porcentaje_hombres_mujeres;

import java.util.Scanner;

/**
 *
 * @author DARIANA
 */
public class Porcentaje_hombres_mujeres {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float nh, nm, ta, ph, pm;
        Scanner leer = new Scanner(System.in);
        System.out.print("Escriba el número de hombres: ");
        nh = leer.nextFloat();
        System.out.print("Escriba el número de mujeres: ");
        nm = leer.nextFloat();
        ta = (float)(nm+nh);
        ph = (float)(nh/ta*100);
        pm = (float)(nm/ta*100);
        System.out.println("El porcentaje de hombres es: "+ph+"%");
        System.out.println("El porcentaje de hombres es: "+pm+"%");
        
    }
    
}
