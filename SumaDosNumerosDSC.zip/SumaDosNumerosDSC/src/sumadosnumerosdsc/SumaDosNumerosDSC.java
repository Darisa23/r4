/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sumadosnumerosdsc;

import java.util.Scanner;

/**
 *
 * @author sdariana
 */
public class SumaDosNumerosDSC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int num1, num2, suma;
        Scanner leer = new Scanner(System.in);
        System.out.print("Digite el primer número: ");
        num1 = leer.nextInt();
        System.out.print("Digite el segundo número: ");
        num2 = leer.nextInt();
        suma = num1 + num2;
        System.out.println("la suma es: "+suma);
        
    }
    
}
