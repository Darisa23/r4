/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calificacion_final;

import java.util.Scanner;

/**
 *
 * @author DARIANA
 */
public class Calificacion_final {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float c1, c2, c3, ef, tf, prom, ppar, pef, ptf, cf;
        Scanner leer = new Scanner(System.in);
        System.out.print("Digite su calificación # 1: ");
        c1 = leer.nextFloat();
        System.out.print("Digite su calificación # 2: ");
        c2 = leer.nextFloat();
        System.out.print("Digite su calificación # 3: ");
        c3 = leer.nextFloat();
        System.out.print("Digite la nota de su examen final: ");
        ef = leer.nextFloat();
        System.out.print("Digite la nota de su trabajo final: ");
        tf = leer.nextFloat();
        prom = (float)(c1 + c2 + c3)/3;
        ppar = (float)( prom * 0.55 );
        pef = (float)( ef*0.3 );
        ptf = (float)(tf*0.15);
        cf = (float)( ppar+pef+ptf );
        System.out.println("Su calificación final en la materia es de: " + cf);
    }
    
}
