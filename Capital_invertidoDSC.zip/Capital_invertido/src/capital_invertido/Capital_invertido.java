/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package capital_invertido;

import java.util.Scanner;

/**
 *
 * @author DARIANA
 */
public class Capital_invertido {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float cap_inv, gan;
        Scanner leer = new Scanner(System.in);
        System.out.print("Capital a invertir: ");
        cap_inv = leer.nextFloat();
        gan = (float) (cap_inv * 0.02);
        System.out.println("Su ganancia en un mes será: "+gan);
    }
    
}
