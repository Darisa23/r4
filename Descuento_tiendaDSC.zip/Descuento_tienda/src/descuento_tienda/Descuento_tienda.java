/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package descuento_tienda;

import java.util.Scanner;

/**
 *
 * @author DARIANA
 */
public class Descuento_tienda {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float tc, d, tp;
        Scanner leer = new Scanner(System.in);
        System.out.print("Ingrese el total de su compra: ");
        tc = leer.nextFloat();
        d = (float) (tc * 0.15); 
        tp = (float) (tc - d);
        System.out.println("El total a pagar es de: "+ tp);
    }
    
}
